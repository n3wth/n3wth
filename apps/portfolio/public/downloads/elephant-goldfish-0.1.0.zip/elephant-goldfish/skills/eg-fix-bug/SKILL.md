---
name: eg-fix-bug
description: Diagnose or fix a bug with an independent Elephant-Goldfish investigation, a demonstrated failure, and verified correction.
---

# Bug diagnosis and repair

Read [the shared protocol](../../references/protocol.md).

1. Establish the observed symptom, expected behavior, exact reproduction, and acceptance for a fix. Derive a repro from available evidence before asking for information the repository already supplies. Inspect current behavior and record your own hypothesis separately from the Goldfish input.
2. Spawn one fresh read-only Goldfish with only the symptom, expected behavior, repro, repository location, and allowed source scope. Ask it to investigate and return up to three ranked causes, file citations, supporting evidence, and what would falsify each. Explicitly omit your suspected module if it is only a hypothesis, proposed fix, prior conclusions, and hidden reasoning. Ask for diagnosis only.
3. Compare evidence after the Goldfish reports. Investigate disagreements; agreement alone does not prove the cause. A diagnosis-only request stops here with the best-supported cause and remaining uncertainty.
4. For an authorized fix, demonstrate failure before editing implementation. Prefer a focused regression test that fails for the reported reason. Where automated testing is disproportionate, use a repeatable manual/browser/API reproduction and retain before/after evidence. An unrelated setup failure does not count as reproducing the bug.
5. Fix the root cause at the responsible layer. Avoid adjacent cleanup. Verify that the same failing case now passes and run required project checks. Reproduce the original user-visible path. Apply the shared two-fix limit before re-diagnosing.
6. Run the bundled [precommit review](../eg-precommit-review/SKILL.md). The existing fix request permits repairs of verified in-scope findings. Report the root cause, fix, before/after evidence, independent agreement or divergence, review result, and unresolved limits.

For purely cosmetic copy or formatting fixes, a direct before/after check may be sufficient; do not manufacture a diagnosis ceremony. Judge configuration and dependency changes by behavior and risk, not line count. Never call an unperformed independent check a pass.
