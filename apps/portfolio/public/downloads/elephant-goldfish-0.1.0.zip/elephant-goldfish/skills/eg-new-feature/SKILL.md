---
name: eg-new-feature
description: Build a feature or stress-test a design using fresh Elephant-Goldfish comprehension, critique, and readiness checks before implementation.
---

# Feature and design check

Read [the shared protocol](../../references/protocol.md).

## Design

Trace the relevant existing behavior and its owner before proposing edits. Produce a compact design artifact with:

- User-visible outcome and non-goals.
- Current behavior and source paths.
- Proposed flow, responsible layers, interfaces, and state changes.
- Material alternatives rejected and the reason, when needed to preserve design intent.
- Failure behavior and applicable security, compatibility, and migration constraints.
- Observable acceptance and concrete verification commands or manual steps.

Reuse existing code or platform behavior first. Resolve only choices that materially affect correctness or authorization. Keep the design in chat unless a saved design is requested or required by project convention.

## Independent checks

Read [the design prompts](../../references/design-prompts.md). Start three fresh, read-only passes for the initial design: comprehension, critic, and readiness. Each gets the same version of the design, its task, repository location, and permitted supporting reads. Never send the other passes' responses.

Default gate: do not edit implementation or tests until critic returns `design ready` AND readiness returns `implementation ready` for the same design version. A missing pass does not open the gate. Comprehension is informational; resolve material ambiguity through the design and report any remaining ambiguity.

For a revision, address every substantive gap or record an evidence-backed rebuttal. Put any essential clarification into the design itself. Run fresh critic and readiness passes on that version. Apply the protocol's initial-plus-two-revisions bound. If a needed product decision remains unanswered, stop the dependent work and present the exact decision.

Explicit user instructions override this workflow default. If the user asks to skip a check, record which check was skipped, continue within authorized scope, and do not claim the design passed it. Do not require special override wording or ask for permission already given.

## Implement and verify

A design-review-only request ends after the checks. If implementation is requested, follow a short plan through the responsible layers. Preserve existing patterns. Add the tests needed to prove acceptance and failure behavior. Run required project checks and focused runtime validation. For UI changes, exercise the flow and a relevant edge case in the browser or simulator when available.

Use the bundled [precommit review](../eg-precommit-review/SKILL.md) on the resulting change. Since implementation is already authorized, fix verified in-scope findings. Do not leak design rationale into the reviewer prompt. Recheck any changed behavior after repairs.

Return the change, actual check results, design verdicts, review findings/rebuttals, and unresolved limits. Do not stage or commit unless requested.
