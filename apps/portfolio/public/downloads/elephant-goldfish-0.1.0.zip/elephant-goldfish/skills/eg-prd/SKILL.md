---
name: eg-prd
description: Write an Elephant-Goldfish PRD grounded in existing code, independent research, explicit requirements, and open questions. Use when requirements are the requested output.
---

# PRD

Read [the shared protocol](../../references/protocol.md).

1. Resolve the idea and output target. Default to a concise PRD in chat. Read relevant existing requirements and project instructions. For an existing product, use one or two fresh read-only Goldfish to inspect distinct areas: existing user-facing behavior and architecture/constraints. Give them the seed and allowed paths. Require current file citations. For a greenfield idea, mark the absence of an existing system instead of inventing one.
2. Identify material gaps in users, scope, acceptance, permissions/data, failure behavior, and success measurement. Ask a small bundled question only where an answer is needed. Keep unanswered choices as Open Questions; never turn guesses into approved requirements.
3. If research is requested or needed, use fresh researchers for the relevant independent lenses, within capacity. Give them the seed, factual codebase brief, and explicit answers. Ask for source-backed findings and implications. Do not send the Elephant's preferred product choice. No mandatory market/compliance sweep for every PRD.
4. Synthesize: problem and users; current state; scope/non-goals; numbered requirements with observable acceptance; failure and security constraints; success measures; risks; open questions; sources. Separate facts, proposed decisions, and unknowns. Scale length to the task.
5. Check that each requirement is testable and each claimed source supports it. Surface conflicts rather than averaging them away.

Save only the requested artifact, using the existing project convention or user path. Do not modify AGENTS.md, durable memory, issue trackers, or product code as a side effect. A PRD request ends with the document. If implementation was also requested, hand the completed requirements to the bundled [feature workflow](../eg-new-feature/SKILL.md); unresolved material choices remain blockers.
