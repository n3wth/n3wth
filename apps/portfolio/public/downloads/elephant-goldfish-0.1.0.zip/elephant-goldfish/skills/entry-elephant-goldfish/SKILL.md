---
name: entry-elephant-goldfish
description: Route an Elephant-Goldfish plugin request to brainstorming, PRD, feature design, bug diagnosis, or independent code review. Use when the plugin is selected or the user requests this method.
---

# Elephant-Goldfish

The Elephant keeps the conversation and project context. Each Goldfish receives a bounded artifact in a fresh context to test assumptions independently.

Read only the selected bundled skill. Resolve paths relative to this file, including when another installed skill has the same name.

| User intent | Bundled workflow |
| --- | --- |
| Explore an idea or compare directions | [eg-brainstorm](../eg-brainstorm/SKILL.md) |
| Turn an idea into requirements | [eg-prd](../eg-prd/SKILL.md) |
| Build a feature or check a design | [eg-new-feature](../eg-new-feature/SKILL.md) |
| Diagnose or fix a bug | [eg-fix-bug](../eg-fix-bug/SKILL.md) |
| Review a diff, branch, PR, or pending changes | [eg-precommit-review](../eg-precommit-review/SKILL.md) |

Honor an explicitly named workflow. Infer the stage from the request; ask only if the goal or target is missing. A design-check request stops after the design check. A diagnosis request stops after diagnosis. Review alone does not authorize repairs. Do not run the whole pipeline for every request.

For help, explain the five choices and fresh-context requirement without spawning agents or inspecting a repository. For provenance or adaptation questions, read [research](../../references/research.md).
