---
name: eg-brainstorm
description: Explore a software or product idea with independent Elephant-Goldfish lenses, then compare options and evidence. Use for divergent idea exploration with this method.
---

# Brainstorm

Read [the shared protocol](../../references/protocol.md).

1. Turn the user's input into a short seed: problem, audience, constraints, success, and non-goals. Distinguish stated facts from assumptions. Reuse answers already given. Ask only about gaps that would materially change the ideas.
2. Choose two or three distinct lenses that fit the question, such as technical feasibility, user need, or contrarian/prior art. Spawn fresh, read-only Goldfish independently. Give each the seed and its lens, without your favored solution or the other lenses' output. Ask for two or three concepts with the underlying bet, failure condition, and cheapest validation step.
3. Research when requested or when current external facts determine feasibility. Use available source tools and cite original sources. Do not treat brainstorming as evidence of demand or invent market facts. Independent reads may run in parallel.
4. Deduplicate and compare concepts by the user's success criteria. Show the strongest options, material disagreements, sources, and what to test next. A shared assumption is not independent confirmation.

Deliver the brief in chat unless the user requests a saved document or a project convention supplies its location. Stop at ideas. Do not silently start a PRD or implementation. If requested, continue through the corresponding bundled skill.
