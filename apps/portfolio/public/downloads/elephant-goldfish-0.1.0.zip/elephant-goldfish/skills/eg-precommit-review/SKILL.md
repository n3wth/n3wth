---
name: eg-precommit-review
description: Review a diff, PR, branch, or pending changes with a fresh Elephant-Goldfish reviewer and an explicit findings ledger. Review-only requests do not apply fixes.
---

# Independent change review

Read [the shared protocol](../../references/protocol.md) and [review scope and prompt](../../references/review-prompt.md).

## Pin scope

Resolve the exact requested scope. Default to local pending changes only when that is the user's request or clearly implied. Inspect status and branch identity. Distinguish staged, unstaged, untracked, and committed changes. Never silently mix them. Resolve a PR's actual base/head or a branch's agreed comparison base; do not guess `main`.

Capture a stable review artifact: immutable base/head SHAs for a committed range; or copies of the requested patch and relevant untracked text files plus content hashes for local pending changes. Keep temporary artifacts outside the reviewed file set and follow project scratch conventions. Record missing/binary coverage. Do not expose secrets in artifacts or logs. For no changes, report that fact and stop without spawning.

Run the repository's required checks relevant to this change when feasible. Inspect commands before running them in review-only mode; use non-fixing variants or an isolated copy for checks that write source/generated files. Run generation only for authorized edits. If a check fails, call it pre-existing only with verified baseline evidence; otherwise leave its cause unresolved. Do not blanket-exempt docs, config, or dependency updates from review.

## Review

Spawn a fresh read-only Goldfish with the bounded review prompt and the exact artifact, plus allowed supporting reads. Give it neutral user-requested focus if any. Do not include the implementation plan, design rationale, expected verdict, suspected bugs, or earlier findings. Do not pass a feature/bug summary as focus merely because this workflow was called from another workflow.

The reviewer examines correctness, security, concurrency, failure paths, compatibility, and meaningful test gaps within scope. It reports concrete findings or `no findings`, together with its coverage limits. Incomplete coverage cannot yield a clean verdict.

## Triage and optional repairs

Verify every finding. Record stable IDs and either confirmed/open, fixed with evidence, or rebutted with the exact reason. Keep findings read-only unless the user also requested fixes or this review is part of an authorized implementation task. A review-only request ends after triage; it does not need a repair loop.

For authorized repairs, fix concrete in-scope issues and rerun affected checks. Freeze a new artifact and start a new fresh reviewer with no prior conclusions. The Elephant separately verifies all prior ledger entries against that new artifact. Stop when that exact version has no remaining confirmed findings, prior entries are settled, and required checks have passed. Use the shared initial-plus-two-fix-round bound.

Before reporting, recheck the source identities/hashes. If inputs changed during review, the verdict belongs only to the old artifact. Re-scope and re-review within the same bound, or report the stale coverage. Do not overwrite concurrent edits.

Return findings first with locations, scope identity, actual test results, exact rebuttals, and coverage limits. Distinguish `no findings` from fully verified. Do not stage, commit, push, or post a PR comment without authorization.
