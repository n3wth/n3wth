# Research and adaptation decisions

Researched 2026-09-27. Selection criteria: clear routing, true context separation, self-contained dependencies, bounded work, source-backed findings, and verifiable packaging. These are design criteria, not a benchmark ranking of plugins.

## Primary sources

1. Dave Rensin, [Elephants, Goldfish and the New Golden Age of Software Engineering](https://drensin.medium.com/elephants-goldfish-and-the-new-golden-age-of-software-engineering-c33641a48874), published 2026-04-27. Read Parts 1 and 2, including the full design, comprehension, critic, readiness, implementation, and onboarding protocol. It defines the context-rich Elephant, fresh Goldfish, and emphasis on explicit design and evaluation. Treat claimed productivity gains as the author's observations, not validated plugin outcomes.
2. Vladyslav Shvedov, [elephant-goldfish](https://github.com/vshvedov/elephant-goldfish/tree/b8ebb3d6b00e39fbb6c619faa27f5bb994091d78), pinned commit `b8ebb3d6b00e39fbb6c619faa27f5bb994091d78` (2026-05-12). Read README, Codex bootstrap, all five Codex SKILL.md files, and MIT license. This is the concrete workflow source. Original copyright is retained in LICENSE.
3. OpenAI, [Agent Skills](https://developers.openai.com/codex/skills). Read the full fetched page. It recommends narrow triggers, progressive disclosure, instruction-first implementations, and explicit inputs/outputs. Skills are the authoring format; plugins are the installable bundle.
4. OpenAI, [Plugins](https://developers.openai.com/codex/plugins). Read the full fetched page. It describes plugin components, host permission boundaries, installation, and new-chat pickup of installed skills.

## Installed plugin patterns inspected

- **Ponytail 2.0.0:** manifest, `entry-ponytail`, and `ponytail-review`. Adopted one public router, bundled-relative dependencies, focused workflows, and short starter prompts. Did not copy its over-engineering-only review scope or blanket minimum-test policy. Inspiration is structural, not copied source.
- **Codex Security 0.1.31:** `security-diff-scan`. Adopted the principle of a fixed review target, coverage accounting, and separating discovery from validation. Did not import its backend, scan lifecycle, or specialist pipeline.
- **Product Design 0.1.56:** `index`. Adopted explicit intent routing and respecting focused requests. Did not import its visual-first process, persistence preflight, or browser requirements.
- **Built-in plugin-creator and skill-creator:** followed the supported scaffold, schema validator, personal marketplace handling, concise skill design, and behavioral-validation guidance. These are the packaging authority for this local build.

## Deliberate changes from upstream

| Upstream behavior | This package | Reason |
| --- | --- | --- |
| Installs five global skills directly | Six skills in one plugin, including router | Requested installable Codex package; leaves existing global skills untouched |
| Assumes `fork_context: false` | Uses the host's real fresh-context API; `fork_turns: "none"` for collaboration tools | Avoid unsupported arguments and accidental full-history forks |
| Local self-pass/CLI fallback | Discloses unavailable independence; produces a bounded handoff | Same-chat role play does not restore independence; no unverified CLI fallback |
| Hard-coded `main` and combined review scopes | Pins the actual requested staged, pending, branch, or PR scope | Prevent false findings against stale or unrelated work |
| Review loop applies fixes | Review-only stays read-only; existing implementation authority permits in-scope fixes | Preserve user intent |
| Up to five code review rounds / three design revisions | Initial pass plus two revision/fix rounds, with re-diagnosis on failure | Bound cost and avoid repeated ineffective patches |
| Later reviewers see previous fixes | Fresh reviewers see the new artifact only; Elephant owns the ledger | Reduce anchoring while preserving accountability |
| Boilerplate questions and rigid override wording | Reuse context; ask about material unknowns; honor explicit user overrides | No repeated approval ceremony |
| Skips all docs/dependency/config-only reviews | Judge actual risk and explicit review scope | A short configuration or dependency change may be consequential |
| PRD can write durable nuggets to AGENTS.md | PRD output only unless additional writes are requested | Avoid changing project behavior as a side effect |

The workflow preserves the three initial feature passes, dual design gate, hidden bug hypothesis, regression evidence, source-based rebuttals, and current-repository validation. No executable helper is included because the host already owns agent dispatch, Git access, and test execution.

The original article also recommends long interviews, mandatory saved design sections, a comprehension loop, and comments at a fixed line interval. This adaptation uses the upstream Codex dual gate with informational comprehension, proportional design detail, project-specific artifact conventions, and evidence-based review. It does not impose timed interviews, blanket comment quotas, or repository-wide README generation. Those are deliberate scope choices, not claims that the article prescribes this exact package.
