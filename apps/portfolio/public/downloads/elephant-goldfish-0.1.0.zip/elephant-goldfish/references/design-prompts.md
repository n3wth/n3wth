# Design pass tasks

Combine each task below with the Goldfish boundary from `protocol.md`, the repository location if relevant, and the exact same design artifact. Identify the artifact version. Do not add the Elephant's private reasoning.

## Comprehension

Read only the supplied design. Paraphrase what the feature does and how the existing system works according to the document. List ambiguities by section. Do not critique architecture or search for the author's intent. End with `comprehension passed` or `comprehension unclear`.

## Critic

Read the supplied design, applicable project instructions, and the current source files it references. Check whether its claims match current behavior, whether scope and interfaces are coherent, and whether failure modes and verification cover the requested outcome. Report concrete implementation-blocking gaps with citations where possible. Do not invent requirements. End with `design ready` only when no material gaps remain; otherwise `design needs revision`. If sources cannot be inspected, report incomplete coverage instead of passing.

## Readiness

Read the supplied design and applicable project instructions. You may inspect only its referenced source interfaces to check feasibility. Could a competent implementer execute and verify this design without making an unanswered material product, data, interface, or security decision? Do not demand exact function names for routine local choices. List each blocking question and the section that should answer it. End with `implementation ready` only when no blocking questions remain; otherwise `implementation not ready`. Do not implement.
