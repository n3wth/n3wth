# Vector icon family

Original native SVG artwork for Elephant-Goldfish, based on the user's selected square concept.

- `main.svg`: plugin logo and composer icon; also usable directly as an SVG favicon.
- `main-dark.svg`: reversed logo for dark surfaces.
- `brainstorm`, `prd`, `feature`, `diagnose`, and `review`: focused workflow icons, each with a matching `-dark.svg` variant.

Every asset has a square `0 0 64 64` viewBox, transparent outer corners, solid color fills, and editable vector geometry. No embedded images, font glyphs, filters, scripts, external references, or gradients. The checkmark uses a rounded vector stroke; other marks use filled geometry.

Palette: ink `#222826`, gold `#D59A35`, ivory `#F6F3EC`. The dark variants exchange ink and ivory while retaining gold. There is no outer cream frame or extra canvas padding.

The family was inspected with librsvg renders at 16, 24, 32, and 64 pixels on light and dark surfaces. At 16 pixels the master reads as a paired mark; use 24 pixels or larger when recognition of both animals matters. Tiny icons should keep their visible text label or accessible name.

Skill-local `assets/icon.svg` files are exact copies of the corresponding light asset. The Codex skill metadata validator requires paths without parent traversal, so these small copies keep every skill self-contained. Update the matching copy when editing an asset.
